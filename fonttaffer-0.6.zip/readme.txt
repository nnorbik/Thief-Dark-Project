FontTaffer 0.6 - A Thief 3 font creation program, by Crispy
-----------------------------------------------------------
"Taffing around with Thief 3 fonts so you don't have to..."


This is a simple command-line application that takes font files and uses them to generate font textures for use with Thief 3.

Fonts in Thief 3 are specified using two files; a file with a .cel extension, and a texture file. The .cel file specifies where in the texture file each character can be found, and the game uses this information to display whatever letters it wants. This application generates both.


0. Licencing
------------

Distribution of this program is covered under a BSD-style licence; see licence.txt.


1. Creating a font texture
--------------------------

IMPORTANT NOTE: You will need the Thief 3 editor before you can use the fonts this program creates. Otherwise you will get very strange results when you try to use them! Caveat emptor.

Full help is available by running the program, but here's a brief example.

fonttaff CARLETON.ttf -s30 -t512 -b

This takes CARLETON.ttf (which must be in the same folder as the application - this program does NOT look in the standard Windows font directory!) and renders it out to a file called CARLETON.bmp. A corresponding CARLETON.cel file is also generated. The font size used is 30 (-s30), the texture is 512x512 pixels large (-t512), and boldface type is used (-b).

Carleton is one of the fonts used in Thief 1 and 2; should you wish to use it to get that old-school Thief feeling, you can get it from http://www.thief-thecircle.com.


2. Using the font texture in-game
---------------------------------

To use your new font, you must do the following things:

1. Remove the black background from the font. This is how I do it in Photoshop 7:
	* Convert the image to greyscale (Image->Mode->Grayscale)
	* Press Ctrl-A (to select the entire image) and Ctrl-C (to copy it)
	* Press Ctrl-D to deselect the image.
	* Promote the background to a real layer (Layer->New->Background from layer)
	* Add a layer mask (Layer->Add Layer Mask->Reveal all)
	* Find the Channels window, and in it select the "Layer 1 mask" channel. Click the eye buttons to hide the "Grey" channel and reveal the "Layer 1 mask" channel.
	* Press Ctrl-V to paste the greyscale image into its own mask.
	* You're done! The image is now ready to be saved in an appropriate format (i.e. DDS).

2. Convert the BMP file to a DDS file. NVidia makes a Photoshop plugin that converts BMP files to DDS files; you can find it on their website (NVidia.com) or by searching the web.

3. Place the DDS and CEL files somewhere that Thief 3 will look for them; namely, the directory [Thief3]\CONTENT\T3\PCTextures\Fonts. NOTE: You must do this in an *editor* installation of Thief 3. If you try and place them straight into a non-editor installation, the font will look completely messed up.

4. Use the font in a book or scroll that you've created. See the existing book .sch files for how to apply different fonts (there's a <font> tag of sorts).

However, if you want to replace an existing font ENTIRELY (for example, replacing Papyrus with Carleton) then there are a couple of extra steps you need to take:

1. Back up the old font files (e.g. Papyrus_21.dds and Papyrus_21.cel), and rename your new files to take the place of the old ones.

2. Turn off blockloading. (Be warned, doing this in a non-editor installation will cause the game to crash!) If you leave blockloading on, then the game will read your new CEL file but will still read the old DDS file from an IBT file! Seriously-messed-up text will result.

If you want to distribute a font with an FM, you will probably need to distribute one or more of the generic IBT files. (Like the Kernel one.) I haven't had time to test which one, but play around with it. Shouldn't be too hard.


3. Can I modify and/or redistribute this program?
-------------------------------------------------

Absolutely! See licence.txt, which you should have received when you downloaded this program.

The program is written in Digital Mars D, a C++-like language without all the ugly warts of C++ but with all of the benefits of using a relatively low-level compiled language. For more information and a free compiler visit: http://www.digitalmars.com/d/


4. It blew up!
--------------

Oh, damn, I thought I took that code out... ;-)

Seriously though, this is in beta and totally unsupported, and I haven't extensively tested all of the ways in which taffing around with fonts can mess up Thief 3. That said, if you need to contact me you can do so via the TTLG Thief III Editor's Guild at http://ttlg.com/forums/forumdisplay.php?f=138, or via Private Message on those same forums.


5. Changelog
------------
Version 0.6 (19 July 2006):
	- Fixed line spacing option. Updated to work with the latest version of the Derelict library.
Version 0.5.1 (6 March 2006):
	- Added --offset-x and --offset-y parameters.
Version 0.5 (5 March 2006):
	- Initial release.


Happy editing!

-- Crispy